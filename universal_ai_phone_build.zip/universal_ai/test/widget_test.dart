import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:universal_ai/main.dart';

void main() {
  testWidgets('Universal AI displays its home screen', (tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const UniversalAiApp());
    await tester.pumpAndSettle();
    expect(find.text('Universal AI'), findsWidgets);
  });
}
