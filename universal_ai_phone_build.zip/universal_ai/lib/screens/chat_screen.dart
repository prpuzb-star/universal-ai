import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/chat_message.dart';
import '../services/ai_service.dart';
import '../services/settings_service.dart';
import '../widgets/message_bubble.dart';
import 'settings_dialog.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final _settingsService = SettingsService();
  final _aiService = AiService();
  final List<ChatMessage> _messages = [];
  AppSettings _settings = AppSettings.defaults;
  bool _loading = true;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final settings = await _settingsService.load();
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('chat_history');
    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List<dynamic>;
        _messages.addAll(list.whereType<Map<String, dynamic>>().map(ChatMessage.fromJson));
      } catch (_) {
        await prefs.remove('chat_history');
      }
    }
    if (!mounted) return;
    setState(() {
      _settings = settings;
      _loading = false;
    });
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('chat_history', jsonEncode(_messages.map((m) => m.toJson()).toList()));
  }

  Future<void> _openSettings() async {
    final updated = await showDialog<AppSettings>(
      context: context,
      builder: (_) => SettingsDialog(initial: _settings),
    );
    if (updated == null) return;
    await _settingsService.save(updated);
    if (!mounted) return;
    setState(() => _settings = updated);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sozlamalar saqlandi')));
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || _sending) return;
    _input.clear();
    setState(() {
      _messages.add(ChatMessage(role: 'user', content: text));
      _sending = true;
    });
    await _saveHistory();
    _jumpToBottom();
    try {
      final answer = await _aiService.sendMessage(settings: _settings, history: List.unmodifiable(_messages));
      if (!mounted) return;
      setState(() => _messages.add(ChatMessage(role: 'assistant', content: answer)));
      await _saveHistory();
    } catch (error) {
      if (!mounted) return;
      final message = error.toString().replaceFirst('Exception: ', '');
      setState(() => _messages.add(ChatMessage(role: 'assistant', content: 'Xatolik: $message')));
      await _saveHistory();
    } finally {
      if (mounted) {
        setState(() => _sending = false);
        _jumpToBottom();
      }
    }
  }

  void _jumpToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _newChat() async {
    if (_messages.isEmpty) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Yangi suhbat'),
        content: const Text('Joriy suhbat tarixini tozalaysizmi?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Yo‘q')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Tozalash')),
        ],
      ),
    );
    if (confirmed != true) return;
    setState(_messages.clear);
    await _settingsService.clearChat();
  }

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    _aiService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 720;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 18,
        title: Row(children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: const LinearGradient(colors: [Color(0xFF8B5CF6), Color(0xFF3B82F6)]),
            ),
            child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 21),
          ),
          const SizedBox(width: 11),
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Universal AI', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            Text('Sizning AI yordamchingiz', style: TextStyle(fontSize: 11, color: Colors.white54)),
          ]),
        ]),
        actions: [
          IconButton(tooltip: 'Yangi suhbat', onPressed: _newChat, icon: const Icon(Icons.add_comment_outlined)),
          IconButton(tooltip: 'Sozlamalar', onPressed: _openSettings, icon: const Icon(Icons.settings_outlined)),
          const SizedBox(width: 8),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1050),
                child: Column(children: [
                  Expanded(
                    child: _messages.isEmpty ? _welcome() : ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.fromLTRB(18, 14, 18, 20),
                      itemCount: _messages.length,
                      itemBuilder: (_, index) => MessageBubble(message: _messages[index]),
                    ),
                  ),
                  if (_sending)
                    const Padding(
                      padding: EdgeInsets.only(left: 22, bottom: 8),
                      child: Row(children: [SizedBox(width: 15, height: 15, child: CircularProgressIndicator(strokeWidth: 2)), SizedBox(width: 10), Text('AI javob tayyorlamoqda...', style: TextStyle(color: Colors.white60, fontSize: 12))]),
                    ),
                  _composer(wide),
                ]),
              ),
            ),
    );
  }

  Widget _welcome() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 650),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(
              width: 76, height: 76,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: const LinearGradient(colors: [Color(0xFF8B5CF6), Color(0xFF2563EB)]),
                boxShadow: [BoxShadow(color: const Color(0xFF8B5CF6).withValues(alpha: 0.25), blurRadius: 35)],
              ),
              child: const Icon(Icons.auto_awesome_rounded, size: 38, color: Colors.white),
            ),
            const SizedBox(height: 22),
            const Text('Nima ustida ishlaymiz?', textAlign: TextAlign.center,
                style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, letterSpacing: -0.6)),
            const SizedBox(height: 9),
            const Text('Savolingizni yozing — Universal AI yordam beradi.',
                textAlign: TextAlign.center, style: TextStyle(color: Colors.white60, fontSize: 14)),
            const SizedBox(height: 25),
            Wrap(spacing: 9, runSpacing: 9, alignment: WrapAlignment.center, children: [
              _suggestion('💡 G‘oya topib ber', 'Menga yangi loyiha uchun 5 ta foydali g‘oya ber.'),
              _suggestion('💻 Kod yozish', 'Flutter dasturlashni noldan o‘rgat.'),
              _suggestion('✍️ Matn yozish', 'Menga professional loyiha tavsifi yozib ber.'),
            ]),
            if (_settings.apiKey.isEmpty) ...[
              const SizedBox(height: 25),
              TextButton.icon(onPressed: _openSettings, icon: const Icon(Icons.key_rounded), label: const Text('Boshlash uchun API kalitini sozlang')),
            ],
          ]),
        ),
      ),
    );
  }

  Widget _suggestion(String label, String prompt) => ActionChip(
        label: Text(label),
        backgroundColor: const Color(0xFF171A2B),
        side: const BorderSide(color: Color(0xFF292D45)),
        onPressed: () {
          _input.text = prompt;
          _send();
        },
      );

  Widget _composer(bool wide) {
    return Padding(
      padding: EdgeInsets.fromLTRB(wide ? 24 : 14, 8, wide ? 24 : 14, 18),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 7, 7, 7),
        decoration: BoxDecoration(
          color: const Color(0xFF171A2B),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: const Color(0xFF343853)),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.18), blurRadius: 18, offset: const Offset(0, 6))],
        ),
        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Expanded(
            child: TextField(
              controller: _input,
              minLines: 1,
              maxLines: 6,
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => _send(),
              decoration: const InputDecoration(
                hintText: 'Universal AI ga xabar yozing...',
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                filled: false,
                contentPadding: EdgeInsets.symmetric(vertical: 11),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Padding(
            padding: const EdgeInsets.only(bottom: 2),
            child: IconButton.filled(
              tooltip: 'Yuborish',
              onPressed: _sending ? null : _send,
              icon: const Icon(Icons.arrow_upward_rounded),
              style: IconButton.styleFrom(backgroundColor: const Color(0xFF8B5CF6), foregroundColor: Colors.white),
            ),
          ),
        ]),
      ),
    );
  }
}
