import 'package:flutter/material.dart';
import '../services/settings_service.dart';

class SettingsDialog extends StatefulWidget {
  const SettingsDialog({super.key, required this.initial});
  final AppSettings initial;

  @override
  State<SettingsDialog> createState() => _SettingsDialogState();
}

class _SettingsDialogState extends State<SettingsDialog> {
  late final TextEditingController _url;
  late final TextEditingController _key;
  late final TextEditingController _model;
  late final TextEditingController _provider;
  bool _obscure = true;

  @override
  void initState() {
    super.initState();
    _url = TextEditingController(text: widget.initial.baseUrl);
    _key = TextEditingController(text: widget.initial.apiKey);
    _model = TextEditingController(text: widget.initial.model);
    _provider = TextEditingController(text: widget.initial.providerName);
  }

  @override
  void dispose() {
    _url.dispose();
    _key.dispose();
    _model.dispose();
    _provider.dispose();
    super.dispose();
  }

  void _save() {
    if (_url.text.trim().isEmpty || _model.text.trim().isEmpty) return;
    Navigator.of(context).pop(AppSettings(
      baseUrl: _url.text,
      apiKey: _key.text,
      model: _model.text,
      providerName: _provider.text,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Row(children: [Icon(Icons.tune_rounded), SizedBox(width: 10), Text('AI sozlamalari')]),
      content: SizedBox(
        width: 460,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: _provider, decoration: const InputDecoration(labelText: 'Provayder nomi', hintText: 'OpenAI-compatible')),
              const SizedBox(height: 12),
              TextField(controller: _url, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'API manzili', hintText: 'https://api.openai.com/v1')),
              const SizedBox(height: 12),
              TextField(controller: _model, decoration: const InputDecoration(labelText: 'Model nomi', hintText: 'gpt-4o-mini')),
              const SizedBox(height: 12),
              TextField(
                controller: _key,
                obscureText: _obscure,
                decoration: InputDecoration(
                  labelText: 'API kaliti',
                  hintText: 'API key',
                  suffixIcon: IconButton(
                    onPressed: () => setState(() => _obscure = !_obscure),
                    icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Eslatma: MVP versiyasida kalit qurilmaning mahalliy sozlamalarida saqlanadi. Umumiy yoki ommaviy ilova uchun server-proksi va xavfsiz kalit boshqaruvi kerak.',
                style: TextStyle(color: Colors.white60, fontSize: 12, height: 1.4),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Bekor qilish')),
        FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_rounded), label: const Text('Saqlash')),
      ],
    );
  }
}
