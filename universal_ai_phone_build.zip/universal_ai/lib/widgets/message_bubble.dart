import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/chat_message.dart';

class MessageBubble extends StatelessWidget {
  const MessageBubble({super.key, required this.message});

  final ChatMessage message;

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == 'user';
    final scheme = Theme.of(context).colorScheme;
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 760),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 7),
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: isUser ? scheme.primary.withValues(alpha: 0.22) : const Color(0xFF171A2B),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: isUser ? scheme.primary.withValues(alpha: 0.35) : const Color(0xFF292D45),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(isUser ? Icons.person_rounded : Icons.auto_awesome_rounded,
                      size: 16, color: isUser ? scheme.primary : const Color(0xFFA78BFA)),
                  const SizedBox(width: 7),
                  Text(isUser ? 'Siz' : 'Universal AI',
                      style: Theme.of(context).textTheme.labelMedium?.copyWith(
                            color: Colors.white70,
                            fontWeight: FontWeight.w700,
                          )),
                  const SizedBox(width: 14),
                  IconButton(
                    tooltip: 'Nusxalash',
                    visualDensity: VisualDensity.compact,
                    onPressed: () => Clipboard.setData(ClipboardData(text: message.content)),
                    icon: const Icon(Icons.copy_rounded, size: 16),
                  ),
                ],
              ),
              SelectableText(
                message.content,
                style: const TextStyle(fontSize: 14.5, height: 1.55, color: Color(0xFFE8EAF5)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
