import 'package:shared_preferences/shared_preferences.dart';

class AppSettings {
  const AppSettings({
    required this.baseUrl,
    required this.apiKey,
    required this.model,
    required this.providerName,
  });

  final String baseUrl;
  final String apiKey;
  final String model;
  final String providerName;

  static const defaults = AppSettings(
    baseUrl: 'https://api.openai.com/v1',
    apiKey: '',
    model: 'gpt-4o-mini',
    providerName: 'OpenAI-compatible',
  );
}

class SettingsService {
  static const _baseUrlKey = 'base_url';
  static const _apiKeyKey = 'api_key';
  static const _modelKey = 'model';
  static const _providerKey = 'provider_name';

  Future<AppSettings> load() async {
    final prefs = await SharedPreferences.getInstance();
    return AppSettings(
      baseUrl: prefs.getString(_baseUrlKey) ?? AppSettings.defaults.baseUrl,
      apiKey: prefs.getString(_apiKeyKey) ?? '',
      model: prefs.getString(_modelKey) ?? AppSettings.defaults.model,
      providerName:
          prefs.getString(_providerKey) ?? AppSettings.defaults.providerName,
    );
  }

  Future<void> save(AppSettings settings) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_baseUrlKey, settings.baseUrl.trim());
    await prefs.setString(_apiKeyKey, settings.apiKey.trim());
    await prefs.setString(_modelKey, settings.model.trim());
    await prefs.setString(_providerKey, settings.providerName.trim());
  }

  Future<void> clearChat() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('chat_history');
  }
}
