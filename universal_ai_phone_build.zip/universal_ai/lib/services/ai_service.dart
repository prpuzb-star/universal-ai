import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/chat_message.dart';
import 'settings_service.dart';

class AiService {
  AiService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  Future<String> sendMessage({
    required AppSettings settings,
    required List<ChatMessage> history,
  }) async {
    if (settings.apiKey.trim().isEmpty) {
      throw Exception('API kaliti kiritilmagan. Sozlamalardan API kalitini kiriting.');
    }
    if (settings.model.trim().isEmpty) {
      throw Exception('Model nomi kiritilmagan.');
    }

    final base = settings.baseUrl.trim().replaceFirst(RegExp(r'/+$'), '');
    final uri = Uri.tryParse('$base/chat/completions');
    if (uri == null || !uri.hasScheme || !uri.hasAuthority) {
      throw Exception('API manzili noto‘g‘ri. Masalan: https://api.openai.com/v1');
    }

    final response = await _client
        .post(
          uri,
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${settings.apiKey.trim()}',
          },
          body: jsonEncode({
            'model': settings.model.trim(),
            'messages': history.map((message) => message.toJson()).toList(),
            'temperature': 0.7,
          }),
        )
        .timeout(const Duration(seconds: 90));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      String detail = response.body;
      try {
        final decoded = jsonDecode(response.body) as Map<String, dynamic>;
        final error = decoded['error'];
        if (error is Map<String, dynamic>) {
          detail = error['message']?.toString() ?? response.body;
        }
      } catch (_) {
        // Keep the raw response when the provider does not return JSON.
      }
      throw Exception('API xatosi (${response.statusCode}): $detail');
    }

    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is! Map<String, dynamic>) {
      throw Exception('API javobi kutilgan formatda emas.');
    }
    final choices = decoded['choices'];
    if (choices is! List || choices.isEmpty) {
      throw Exception('AI javob qaytarmadi. Model yoki API sozlamalarini tekshiring.');
    }
    final message = (choices.first as Map<String, dynamic>)['message'];
    final content = message is Map<String, dynamic> ? message['content'] : null;
    if (content is! String || content.trim().isEmpty) {
      throw Exception('AI bo‘sh javob qaytardi.');
    }
    return content.trim();
  }

  void dispose() => _client.close();
}
