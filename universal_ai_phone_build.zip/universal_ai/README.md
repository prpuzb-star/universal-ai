# Universal AI — MVP

Flutter application for Android and Windows. The first version provides an AI chat UI, configurable OpenAI-compatible API endpoint/model/key, local chat history, and copyable messages.

## Requirements
- Flutter stable (Dart 3.3+)
- Android: Android Studio + Android SDK
- Windows: Windows 10/11 and Visual Studio 2022 with **Desktop development with C++** workload

## Run
```bash
flutter doctor
flutter create --platforms=android,windows .
flutter pub get
flutter run
```

## Build Android APK
```bash
flutter build apk --release
```
Output: `build/app/outputs/flutter-apk/app-release.apk`

## Build Windows
```bash
flutter config --enable-windows-desktop
flutter create --platforms=android,windows .
flutter pub get
flutter build windows --release
```
Output: `build/windows/x64/runner/Release/`

## Configure AI
Open Settings in the app and enter:
- Provider name: any label (for example, OpenAI or OpenRouter)
- API URL: OpenAI-compatible base URL, e.g. `https://api.openai.com/v1`
- Model: model identifier supported by your provider
- API key: key issued by that provider

The app calls `POST {API URL}/chat/completions` and expects an OpenAI-compatible response format. Other providers may require different request formats and are not guaranteed to work without an adapter.

## Security note
This MVP stores the API key in local app preferences. This is suitable only for personal testing, not for distributing a public app. A production release should route requests through a backend and keep provider keys on the server. Do not commit real API keys to source control.

## Current limitations
- Text chat only; image generation, voice, file upload, accounts, sync, and admin panel are not included yet.
- Chat history is local to the device.
- The build must be run on a machine with Flutter and the platform toolchains installed.
